<?php
include_once("includes/pagesource.php"); ?>

<body>

    <div class="loader dark center">
        <h2>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h2>
    </div>



    <?php include_once("includes/header.php"); ?>
    <div class="container-fluid banner">
        <div class="banner-bk"></div>
        <div id="particles-js"></div>
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-md-5 text-white text-center text-lg-start position-relative z-index-1 d-flex flex-column justify-content-center h-100 md-mt-50px md-mb-20px xs-mb-10px appear anime-child anime-complete">
                    <p class="banner-heading">HOPECON<br>2024</p>
                    <p class="banner-sub">3rd National Comprehensive Multidisciplinary<br>Medi-Educare Conference</p>
                    <p class="banner-date"><i class="fas fa-calendar"></i>28th June - 30th June || FRIDAY - SUNDAY</p>
                    <p class="banner-date pb-0 border-0"><i class="fas fa-map-marker"></i>ITC Royal Bengal, Kolkata</p>
                    <P class="banner-theme">THEME: Comprehensive Healthcare - The Complete Care</P>

                    <!--<div class="overflow-hidden text-left">
                        <a href="#" class="btn btn-extra-large p-0" style="outline: none;">
                            <span class="btn-body">
                                <span class="label-up">Get Start</span>
                                <span class="label-up">Get Start</span>
                            </span>
                        </a>
                         <a href="https://www.youtube.com/watch?v=cfXHhfNy7tU" class="btn btn-link btn-hover-animation-switch btn-extra-large text-white popup-youtube btn-icon-left">
                            <span>
                                <span class="btn-text">How it works</span>
                                <span class="btn-icon"><i class="fas fa-youtube"></i></span>
                                <span class="btn-icon"><i class="fas fa-youtube"></i></span>
                            </span>
                        </a> 
                    </div>-->

                </div>
                <div class="col-md-7 position-relative">
                    <ul class="banner-list">
                        <li><b>25+</b> Medical Disciplines</li>
                        <li><b>200+</b> Sessions</li>
                        <li><b>500+</b> Experts</li>
                    </ul>
                    <div class="owl-carousel bannerslide">
                        <div class="item">
                            <atropos-component>
                                <div class="atropos">
                                    <div class="atropos-scale">
                                        <div class="atropos-rotate">
                                            <div class="atropos-inner">
                                                <img class="atropos-spacer" src="https://craftohtml.themezaa.com/images/demo-elearning-hero-banner-01.png" alt="stars">
                                                <img data-atropos-offset="-1" src="https://craftohtml.themezaa.com/images/demo-elearning-hero-banner-01.png" alt="stars">
                                                <img data-atropos-offset="1" src="images/demo-elearning-hero-banner-02.webp" alt="mountains">
                                            </div>
                                            <div class="atropos-shadow d-none"></div>
                                        </div>
                                    </div>
                                </div>
                            </atropos-component>
                        </div>
                        <div class="item">
                            <atropos-component>
                                <div class="atropos">
                                    <div class="atropos-scale">
                                        <div class="atropos-rotate">
                                            <div class="atropos-inner">
                                                <img class="atropos-spacer" src="https://craftohtml.themezaa.com/images/demo-elearning-hero-banner-01.png" alt="stars">
                                                <img data-atropos-offset="-1" src="https://craftohtml.themezaa.com/images/demo-elearning-hero-banner-01.png" alt="stars">
                                                <img data-atropos-offset="1" src="images/demo-elearning-hero-banner-02.webp" alt="mountains">
                                            </div>
                                            <div class="atropos-shadow d-none"></div>
                                        </div>
                                    </div>
                                </div>
                            </atropos-component>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6">
        <div class="container">
            <div class="row">
                <div class="heading text-center">
                    <p></p>
                    <h2>Scientific Session</h2>
                    <span></span>
                </div>
                <div class="col-md-12 counter-wrap">
                    <div class="counter-box">
                        <h3>12+</h3>
                        <p>Symposia</p>
                    </div>
                    <div class="counter-box">
                        <h3>70+</h3>
                        <p>Case Discussions</p>
                    </div>
                    <div class="counter-box">
                        <h3>20+</h3>
                        <p>Live Workshops</p>
                    </div>
                    <div class="counter-box">
                        <h3>20+</h3>
                        <p>Expert Panels</p>
                    </div>
                    <div class="counter-box">
                        <h3>50+</h3>
                        <p>Recent Advances</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 city-sec">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-md-5 heading mb-0">
                    <p class="text-muted">Welcome to</p>
                    <h2 class="text-white">HOPECON 2024</h2>
                    <p class="text-muted">in The Dynamic City of Joy - KOLKATA</p>
                </div>
                <div class="content col-12 col-md-6 offset-md-1">
                    <p class="text-white mb-0">
                        An unparalleled gathering of healthcare professionals, researchers, and experts from across the country. This event serves as a platform for collaboration, innovation, and knowledge exchange in the ever-evolving field of medicine.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid wlcm-wrap">
        <img src="https://industrie.rstheme.com/factory/wp-content/uploads/2024/01/faq-h2-bg1.jpg" class="wlcm-bk">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 col-md-6 wlcm-box">
                    <div class="heading">
                        <p class="d-none">Welcome to</p>
                        <h2 class="text-white">In HOPECON, we deliver:</h2>
                        <span class="d-none">in The Dynamic City of Joy - KOLKATA</span>
                    </div>
                    <ul class="faq-wrap">
                        <li>
                            <h6 class="faq-clk">Diverse Range of Topics</h6>
                            <div class="faqx">
                                <p>A wide 25+ medical disciplines</p>
                            </div>
                        </li>
                        <li>
                            <h6 class="faq-clk">Renowned Speakers</h6>
                            <div class="faqx">
                                <p>Engage with leading experts and pioneers from all across the country</p>
                            </div>
                        </li>
                        <li>
                            <h6 class="faq-clk">Interactive Workshops</h6>
                            <div class="faqx">
                                <p>Participate in hands-on workshops and skill-building sessions</p>
                            </div>
                        </li>
                        <li>
                            <h6 class="faq-clk">Cutting-edge Research</h6>
                            <div class="faqx">
                                <p>Latest advancements and breakthroughs in medical research</p>
                            </div>
                        </li>
                        <li>
                            <h6 class="faq-clk">Networking Opportunities</h6>
                            <div class="faqx">
                                <p>Connect with peers, mentors and collaborators from diverse backgrounds to foster meaningful partnerships and collaborations</p>
                            </div>
                        </li>
                        <li>
                            <h6 class="faq-clk">Continuing Medical Education (CME) Credits</h6>
                            <div class="faqx">
                                <p>Earn CME credits by attending accredited sessions, ensuring ongoing professional development and certification requirements</p>
                            </div>
                        </li>
                        <li>
                            <h6 class="faq-clk">Industry Exhibition</h6>
                            <div class="faqx">
                                <p>Latest medical technologies and healthcare services showcased by leading industry partners and exhibitors</p>
                            </div>
                        </li>
                        <li>
                            <h6 class="faq-clk">Social Responsibility Initiatives</h6>
                            <div class="faqx">
                                <p>Engage in discussions on healthcare equity, accessibility, and community outreach programs aimed at addressing societal healthcare challenges</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-12 col-md-6 wlcm-box">
                    <div class="heading">
                        <p class="d-none">Welcome to</p>
                        <h2 class="text-white">New Initiative</h2>
                        <span class="d-none">in The Dynamic City of Joy - KOLKATA</span>
                    </div>
                    <div class="content mb-5">
                        <p class="text-white"><b>Virtual Attendance Option:</b> For those unable to attend in person, virtual participation options will be available, ensuring inclusivity and accessibility.
                        </p>
                    </div>
                    <div class="heading">
                        <p class="d-none">Welcome to</p>
                        <h2 class="text-white">HOPECON 2024 Offers</h2>
                        <span class="d-none">in The Dynamic City of Joy - KOLKATA</span>
                    </div>
                    <ul class="wel-offer">
                        <li>Insights into emerging trends and best practices shaping the future of healthcare</li>
                        <li>Expand your professional network and forge collaborations with peers and experts</li>
                        <li>Enhance your skills and knowledge through interactive workshops and educational sessions</li>
                        <li>Contribute to the advancement of medical science and patient care in India</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6">
        <div class="container">
            <div class="row">
                <div class="col-md-12 message-wrap">
                    <div class="message-box">
                        <div class="heading">
                            <h2>Empowering Healthcare Uniting Experts Nationwide
                            </h2>
                            <p>Join us at the forefront of medical innovation and collaboration. Together, lets pave the way for a healthier and more vibrant future for all </p>

                        </div>
                        <div class="content">
                            <p>Dear Colleagues,<br><br>
                                It is our distinct pleasure to reveal the upcoming HOPECON 2024, the third edition of the esteemed National Medieducare Conference organized by the KOLKATA NURTURE FOUNDATION & UNIEDUHEALTH, in the dynamic city of joy - Kolkata.
                                <br><br>
                                We express our sincere gratitude to each one of you -all the participants, who have steadfastly supported us on this exciting & extraordinary journey.
                                <br><br>
                                In the previous year, we were privileged to welcome 3876 delegates and glean invaluable insights from 427 distinguished faculty members, hailing from all over the country. This year, we aspire to transcend these milestones, aiming to make HOPECON 2024 even more expansive and enlightening.
                                <br><br>
                                Every encounter serves as a valuable learning opportunity and we are committed to leveraging past experiences to enrich our knowledge. In this rendition, we are thrilled to introduce new disciplines such as Infertility, Medical Microbiology, Artificial Intelligence, Biomedical Research and Clinical Trials, Radiology, Public Health & many more in addition to our existing 25 fraternities.
                                <br><br>
                                From bedside clinics to healthcare entrepreneurship, our agenda this year encompasses a broad spectrum of topics. Notable additions include customized courses for healthcare professionals, crafted by key opinion leaders and experts, as well as the initiation of the HOPE HEALTH digital campaign, aimed at promoting health awareness nationwide throughout the year.
                                <br><br>
                                HOPECON 2024 aims in<br>
                                "Empowering Healthcare: Uniting Experts Nationwide"
                                <br><br>
                                Our primary objective remains to equip every physician with essential practical insights and the latest advancements. As we believe in involved dialogue instead of monologue, the conference will feature a wide range of competitions, interactive sessions, and immersive workshops along with debates, panel discussions to further enhance the learning experience.
                                <br><br>
                                We eagerly anticipate your participation at HOPECON, as we stand united in this enriching pursuit.
                                <br><br>
                                Warm regards<br>
                                <b>ORGANIZING TEAM</b><br>
                                <b>HOPECON 2024</b>
                            </p>

                        </div>
                    </div>
                    <div class="message-image-box">
                        <img src="images/message.jpg" class="w-100">
                        <a class="popup-youtube" href="https://www.youtube.com/watch?v=pBFQdxA-apI"> <img src="images/playbtn.png" class="counter"></a>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 green_bg">
        <div class="container">

            <div class="heading text-center">
                <p>Our Committee</p>
                <h2>Foundation Committee</h2>
                <span>Committee</span>
            </div>
            <div class="row align-items-center mb-4">
                <div class="col-sm-6">
                    <div class="users_collection d-flex align-items-center">
                        <div class="usersimg">
                            <div class="owl-carousel userslide">
                                <div class="item">
                                    <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                                </div>
                                <div class="item">
                                    <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                                </div>
                                <div class="item">
                                    <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                                </div>
                            </div>
                        </div>
                        <h2>Trusted by <strong>25,000+</strong> happy<br> customers are using crafto.</h2>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="row">
                        <div class="col-6 text-center">
                            <h1><strong>200+</strong></h1>
                            <h6>Creative team to<br>care for projects.</h6>
                        </div>
                        <div class="col-6 text-center">
                            <h1><strong>4.9</strong></h1>
                            <div class="text-warning">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <h6>2,488 Rating</h6>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Payodhi Dhar</h5>
                            <p>Founder</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Apurba Kumar Mukherjee</h5>
                            <p>Co-Founder</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Pradip Kumar Mitra</h5>
                            <p>Convenor</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Arup Dasbiswas</h5>
                            <p>Organising President</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Hari Shankar Pathak</h5>
                            <p>Organising Vice-President</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Gautam Saha</h5>
                            <p>Organising Secretary</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Raja Dhar</h5>
                            <p>Joint Organising Secretary </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Upal Sengupta</h5>
                            <p>Joint Organising Secretary</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Anjan Adhikari</h5>
                            <p>Editor & Asst Treasurer</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Arup Kumar Kundu</h5>
                            <p>Scientific Chairman</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Rana Bhattachariee</h5>
                            <p>Scientific Secretary</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Arunansu Talukdar</h5>
                            <p>Conference Coordination Chairman</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Tirthankar Dasgupta</h5>
                            <p>Conference Coordination Secretary</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 text-center">
                    <a href="committee.php" style="    background: #737315;
    display: inline-block;
    padding: 13px 28px;
    border-radius: 50px;
    color: white;">See More</a>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 text-center heading ">
                    <p class="d-none">Welcome to</p>
                    <h2>Highlights</h2>
                    <span class="d-none">in The Dynamic City of Joy - KOLKATA</span>
                </div>
                <div class="col-12 text-center mb-4">
                    <h2>Concepts</h2>

                </div>
                <div class="col-12 col-md-8 offset-md-2 mb-4">
                    <div class="owl-carousel owl-theme conseptslide">
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/cardiogram.png">
                                    <p>Cardiology</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/medical-care.png">
                                    <p>Critical Care</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/dermatology.png">
                                    <p>Dermatology</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/telemedicine.png">
                                    <p>Digital Health</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/endocrine.png">
                                    <p>Endocrinology</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/first-aid-kit.png">
                                    <p>Forensic Medicine & Toxicology</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/stomach.png">
                                    <p>Gastroenterology</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/geriatrics.png">
                                    <p>Geriatric Medicine</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/hematology.png">
                                    <p>Hematology</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/medicine.png">
                                    <p>Internal Medicine</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/nanotechnology.png">
                                    <p>Medical Pharmacology & Therapeutics</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/medical-book.png">
                                    <p>Medical Education</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/oncology.png">
                                    <p>Medical Oncology</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/kidney.png">
                                    <p>Nephrology</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/neurology.png">
                                    <p>Neurology</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/microscope.png">
                                    <p>Pathology & Lab Medicine</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/massage.png">
                                    <p>Physical Medicine & Rehabilitation</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/psychiatry.png">
                                    <p>Psychiatry</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/lungs.png">
                                    <p>Respiratory Medicine</p>
                                </div>
                                <div class="consept-box">
                                    <img src="images/rheumatology.png">
                                    <p>Rheumatology</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box">
                                    <img src="images/drugs.png">
                                    <p>Tropical Medicine</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 text-center mb-4">
                    <h2>Competitions with Awards</h2>
                </div>
                <div class="col-12 col-md-8 offset-md-2 mb-4">
                    <div class="owl-carousel owl-theme conseptslide comipition">
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box competetion-box">
                                    <img src="images/contestant.png">
                                    <p>MediQuiz</p>
                                </div>
                                <div class="consept-box competetion-box">
                                    <img src="images/debate.png">
                                    <p>Debate</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box competetion-box">
                                    <img src="images/businessman (1).png">
                                    <p>Extempore</p>
                                </div>
                                <div class="consept-box competetion-box">
                                    <img src="images/doctor.png">
                                    <p>Medical Writing</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box competetion-box">
                                    <img src="images/presentation.png">
                                    <p>Paper Presentation</p>
                                </div>
                                <div class="consept-box competetion-box">
                                    <img src="images/poster.png">
                                    <p>Poster Presentation</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box competetion-box">
                                    <img src="images/health.png">
                                    <p>Health Awareness Painting</p>
                                </div>
                                <div class="consept-box competetion-box">
                                    <img src="images/candidate.png">
                                    <p>Public Health Campaign Competition</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box competetion-box">
                                    <img src="images/presentation (1).png">
                                    <p>Faculty Paper Presentation</p>
                                </div>
                                <div class="consept-box competetion-box">
                                    <img src="images/poster (1).png">
                                    <p>Research Poster Presentation</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="consept-wrap">
                                <div class="consept-box competetion-box">
                                    <img src="images/innovation.png">
                                    <p>Medical Innovation Concept Competition</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-12 text-center mb-4">
                    <h2>Unique Topics</h2>
                </div>
                <div class="col-12 col-md-8 offset-md-2">
                    <ul class="uniqslide">
                        <li>Psychosomatic Comprehensive Health</li>
                        <li>Physician - Pharmaceutical Interface</li>
                        <li>Healthcare Entrepreneurship</li>
                        <li>KOL Connect</li>
                        <li>Medical Finance Management</li>
                        <li>Novel Career Opportunities</li>
                        <li>Digital Healthcare</li>
                        <li>Artificial Intelligence in Healthcare</li>
                        <li>Medico Legal Issues</li>
                        <li>Modern Medical Research</li>
                        <li>Quality & Patient Safety</li>
                        <li>Global Opportunities in Health Care</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="sticky-contents">
                        <div class="shedule_lft">
                            <div class="heading">
                                <p>Join Us</p>
                                <h2>Registartion</h2>
                                <span>Registartion</span>
                            </div>
                            <div class="content">
                                <p>Captivating performances, interactive workshops, and delightful culinary delights await you at Harmonia Music Festival. Let the melodies transcend boundaries on this unforgettable musical journey.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="shedule_rt">
                        <ul class="schedule-tabs">
                            <li class="tabsitem active" data-id="day1">
                                <span class="fs-3 fw-extra-bold mb-0 custom-roboto">EARLY BIRD ENTRY</span>
                                <span class="fs-5 fw-semibold mb-0 custom-roboto d-none d-lg-block">till 30th April, 2024</span>
                            </li>
                            <li class="tabsitem" data-id="day2">
                                <span class="fs-3 fw-extra-bold mb-0 custom-roboto">REGULAR ENTRY</span>
                                <span class="fs-5 fw-semibold mb-0 custom-roboto d-none d-lg-block">25th June, 2024</span>
                            </li>
                            <li class="tabsitem" data-id="day3">
                                <span class="fs-3 fw-extra-bold mb-0 custom-roboto">SPOT ENTRY</span>
                            </li>
                        </ul>
                        <div class="schedule-content active" id="day1">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 1000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>JUNIOR DOCTOR (House Staff, JR, SR, PGT, PDT)</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 2000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 4000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>SENIOR DOCTOR</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 7500</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 8000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>CORPORATE / SPONSORED DELEGATES</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>NA</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="schedule-content" id="day2">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 1500</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>JUNIOR DOCTOR (House Staff, JR, SR, PGT, PDT)</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 2000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 7500</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>SENIOR DOCTOR</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 7500</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 10000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>CORPORATE / SPONSORED DELEGATES</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>NA</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="schedule-content" id="day3">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 12000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>JUNIOR DOCTOR (House Staff, JR, SR, PGT, PDT)</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 2000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 12000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>SENIOR DOCTOR</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 7500</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>₹ 12000</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>CORPORATE / SPONSORED DELEGATES</h3>
                                    </div>
                                </li>
                                <li class="list-group-item d-md-flex justify-content-start align-items-start">
                                    <div class="me-auto" style="min-width: 170px;">
                                        <h3 class="text-nowrap"><b>NA</b></h3>
                                    </div>
                                    <div class="ml-md-5 me-auto w-100">
                                        <h3>ACCOMPANYING GUEST</h3>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid city-sec py-6">
        <div class="container">
            <div class="heading text-center">
                <p class="text-muted">Our Locations</p>
                <h2 class="text-white">Our Locations</h2>
                <span class="text-muted">Locations</span>
            </div>
            <div class="row">
                <div class="col-md-6 m-auto">
                    <div class="owl-carousel owl-theme cityslide">
                        <div class="item"><img src="https://www.squareyards.com/blog/wp-content/uploads/2021/11/victoria-memorial_1.jpg">
                            <h2>Victoria Memorial</h2>
                        </div>
                        <div class="item"><img src="https://www.biswabanglagatekolkata.in/images/biswabanglaBanner.jpg">
                            <h2>Biswa Bangla</h2>
                        </div>
                        <div class="item"><img src="https://www.roadtraffic-technology.com/wp-content/uploads/sites/17/2010/11/Image-1-Howrah-Bridge.jpg">
                            <h2>Howrah Bridge</h2>
                        </div>
                        <div class="item"><img src="https://www.squareyards.com/blog/wp-content/uploads/2021/11/victoria-memorial_1.jpg">
                            <h2>Victoria Memorial</h2>
                        </div>
                        <div class="item"><img src="https://www.biswabanglagatekolkata.in/images/biswabanglaBanner.jpg">
                            <h2>Biswa Bangla</h2>
                        </div>
                        <div class="item"><img src="https://www.roadtraffic-technology.com/wp-content/uploads/sites/17/2010/11/Image-1-Howrah-Bridge.jpg">
                            <h2>Howrah Bridge</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6">
        <div class="container">
            <div class="row">
                <div class="col-md-6 d-flex align-items-center">
                    <div>
                        <div class="heading">
                            <p>Join Us</p>
                            <h2>Venue</h2>
                            <span>Join Us</span>
                        </div>
                        <div class="content">
                            <p>Become Part of Our Harmonious Community and Receive Exclusive Updates, Special Offers, and Exciting News about the Festival Straight to Your Inbox.</p>

                            <div class="icon_content mb-2">
                                <span><i class="fa fa-map-marker"></i></span>
                                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            </div>
                            <div class="icon_content mb-2">
                                <span><i class="fa fa-phone"></i></span>
                                +91 9876543210
                            </div>
                            <div class="icon_content mb-2">
                                <span><i class="fa fa-envelope"></i></span>
                                demoemail@email.com
                            </div>
                            <div class="icon_content mb-2">
                                <span><i class="fa fa-train"></i></span>
                                Kolkata - Howrah
                            </div>

                            <!-- <div class="email_group mb-3 mt-4">
                                <input type="email" class="form-control" placeholder="Enter your Email id">
                                <button type="button" class="btn"><i class="fa fa-paper-plane"></i></button>
                            </div> -->
                        </div>
                    </div>
                </div>
                <div class="col-md-6 text-center">
                    <div class="heading">
                        <h2>Biswa bangla Convention Centre</h2>
                    </div>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3097.791414892802!2d88.4731636905361!3d22.582260096303237!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a027533fc949189%3A0x3ab3e61f8d2a65c!2sBISWA%20BANGLA%20CONVENTION%20CENTRE%2C%20Action%20Area%20I%2C%20Newtown%2C%20New%20Town%2C%20West%20Bengal%20700156!5e0!3m2!1sen!2sin!4v1711610210991!5m2!1sen!2sin" style="width:100%" height="450" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>
    <?php include_once("includes/footer.php"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
</body>
<script>
    $(document).ready(function() {
        $('.faq-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(".faq-clk").parent().removeClass("active");
            } else {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(".faq-clk").parent().removeClass("active");
                $(this).parent().find(".faqx").slideToggle();
                $(this).parent().toggleClass("active");
                $(this).parent().find(".faq-clk").toggleClass("active");
            }
        });
    });

    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        setTimeout(function() {
            $('.loader').fadeOut(500);
        }, 5000);
    });
    /*---------dynamic tab--------*/
    $(document).ready(function() {
        $(document).on("click", ".tabsitem", function() {
            $('.tabsitem').removeClass('active');
            $(this).addClass('active');
            var currentTab = $(this).attr('data-id');
            $('.schedule-content').removeClass('active');
            $('#' + currentTab).addClass('active');
        });
    });

    new WOW().init();

    $('.bannerslide').owlCarousel({
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: false,
        center: true,
        items: 1,
        loop: true,
        nav: false,
        dots: false,
        margin: 0,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        responsive: {
            600: {
                items: 1
            }
        }
    });

    $('.cityslide').owlCarousel({
        center: true,
        items: 1,
        loop: true,
        nav: true,
        margin: 10,
        responsive: {
            600: {
                items: 1
            }
        }
    });
    $('.conseptslide').owlCarousel({
        items: 4,
        loop: false,
        nav: true,
        dots: false,
        margin: 10,
         navText: [
            '<i class="fas fa-arrow-left"></i>',
            '<i class="fas fa-arrow-right"></i>'
        ],
        responsive: {
            300: {
                items: 1
            },
            1024: {
                items: 4
            }
        }
    });

    $('.userslide').owlCarousel({
        center: true,
        items: 1,
        loop: true,
        nav: false,
        margin: 0,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        autoplay: true,
        responsive: {
            600: {
                items: 1
            }
        }
    });
</script>
<script>
    $(function() {
        $('.popup-youtube, .popup-vimeo').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: false,
            fixedContentPos: false
        });
    });
</script>
<script>
    var randomScalingFactor = function() {
        return Math.round(Math.random() * 100);
    };

    var randomData = function() {
        return [
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor()
        ];
    };

    var randomValue = function(data) {
        return Math.max.apply(null, data) * Math.random();
    };

    var data = randomData();
    var value = randomValue(data);

    var config = {
        type: 'gauge',
        data: {
            labels: ['Success', 'Warning', 'Warning', 'Error'],
            datasets: [{
                data: data,
                value: value,
                backgroundColor: ['#0b152c', '#3e3f3e', '#dc1e33', '#c32032'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,

            },
            layout: {
                padding: {
                    bottom: 30
                }
            },
            needle: {
                // Needle circle radius as the percentage of the chart area width
                radiusPercentage: 2,
                // Needle width as the percentage of the chart area width
                widthPercentage: 3.2,
                // Needle length as the percentage of the interval between inner radius (0%) and outer radius (100%) of the arc
                lengthPercentage: 80,
                // The color of the needle
                color: 'rgba(14, 30, 42, 1)'
            },
            valueLabel: {
                formatter: Math.round
            }
        }
    };

    window.onload = function() {
        var ctx = document.getElementById('chart').getContext('2d');
        window.myGauge = new Chart(ctx, config);
    };

    document.getElementById('randomizeData').addEventListener('click', function() {
        config.data.datasets.forEach(function(dataset) {
            dataset.data = randomData();
            dataset.value = randomValue(dataset.data);
        });

        window.myGauge.update();
    });
</script>
<script>
    const counters = document.querySelectorAll(".counter");

    counters.forEach((counter) => {
        counter.innerText = "0";
        const updateCounter = () => {
            const target = +counter.getAttribute("data-target");
            const count = +counter.innerText;
            const increment = target / 200;
            if (count < target) {
                counter.innerText = `${Math.ceil(count + increment)}`;
                setTimeout(updateCounter, 1);
            } else counter.innerText = target;
        };
        updateCounter();
    });
    class AtroposComponent extends HTMLElement {
        constructor() {
            super();
        }

        connectedCallback() {
            this.atropos = new Atropos({
                el: this.querySelector('.atropos'),
                onEnter() {
                    console.log('Atropos Component: Enter');
                },
                onLeave() {
                    console.log('Atropos Component: Leave');
                },
                onRotate(x, y) {
                    console.log('Atropos Component: Rotate', x, y);
                }
            });

            console.log('Atropos Component: Connected!', this);
        }

        disconnectedCallback() {
            this.atropos.destroy();

            console.log('Atropos Component: Disconnected!', this);
        }
    }

    customElements.define('atropos-component', AtroposComponent);
    particlesJS("particles-js", {
        "particles": {
            "number": {
                "value": 6,
                "density": {
                    "enable": true,
                    "value_area": 800
                }
            },
            "color": {
                "value": "#d5d52b"
            },
            "shape": {
                "type": "circle",
                "stroke": {
                    "width": 0,
                    "color": "#000000"
                },
                "polygon": {
                    "nb_sides": 0
                },
                "image": {
                    "src": "img/github.svg",
                    "width": 100,
                    "height": 100
                }
            },
            "opacity": {
                "value": 0.5,
                "random": false,
                "anim": {
                    "enable": false,
                    "speed": 1,
                    "opacity_min": 0.1,
                    "sync": false
                }
            },
            "size": {
                "value": 8,
                "random": true,
                "anim": {
                    "enable": false,
                    "speed": 3,
                    "size_min": 1,
                    "sync": false
                }
            },
            "line_linked": {
                "enable": false,
                "distance": 150,
                "color": "#ffffff",
                "opacity": 0.4,
                "width": 1
            },
            "move": {
                "enable": true,
                "speed": 3,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "bounce": false,
                "attract": {
                    "enable": false,
                    "rotateX": 600,
                    "rotateY": 1200
                }
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
                "onhover": {
                    "enable": true,
                    "mode": "grab"
                },
                "onclick": {
                    "enable": true,
                    "mode": "push"
                },
                "resize": true
            },
            "modes": {
                "grab": {
                    "distance": 140,
                    "line_linked": {
                        "opacity": 1
                    }
                },
                "bubble": {
                    "distance": 400,
                    "size": 40,
                    "duration": 2,
                    "opacity": 8,
                    "speed": 3
                },
                "repulse": {
                    "distance": 200,
                    "duration": 0.4
                },
                "push": {
                    "particles_nb": 4
                },
                "remove": {
                    "particles_nb": 2
                }
            }
        },
        "retina_detect": true
    });


    /* ---- stats.js config ---- */

    var count_particles, stats, update;
    stats = new Stats;
    stats.setMode(0);
    stats.domElement.style.position = 'absolute';
    stats.domElement.style.left = '0px';
    stats.domElement.style.top = '0px';
    document.body.appendChild(stats.domElement);
    count_particles = document.querySelector('.js-count-particles');
    update = function() {
        stats.begin();
        stats.end();
        if (window.pJSDom[0].pJS.particles && window.pJSDom[0].pJS.particles.array) {
            count_particles.innerText = window.pJSDom[0].pJS.particles.array.length;
        }
        requestAnimationFrame(update);
    };
    requestAnimationFrame(update);
</script>


</html>