<?php
include_once("includes/pagesource.php"); ?>

<body>

    <div class="loader dark center">
        <h2>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h2>
    </div>
    <?php include_once("includes/header.php"); ?>

    <div class="container-fluid py-6 green_bg">
        <div class="container">

            <div class="heading text-center">
                <p>Our Committee</p>
                <h2>Advisory Committee</h2>
                <span>Committee</span>
            </div>
            <div class="row">
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sukumar Mukherjee

                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Chittaranjan Maity
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Rabindranath Chatterjee
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sumita Sarkar
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sushanta Kumar Bandyopadhyay
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Siddhartha Chakraborty
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Devanu Ghosh Roy
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Ananda Bagchi
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Indranil Biswas
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Arijit Coondoo
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Anirban Majumder
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Tapan Kumar Biswas
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Monojit Mookherjee</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>
                                Dr Udas Chandra Ghosh</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>
                                Dr Jayanta Mukherjee</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-6">
        <div class="container">

            <div class="heading text-center">
                <p>Our Committee</p>
                <h2>Executive Committee</h2>
                <span>Committee</span>
            </div>
            <div class="row">
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Payel Talukdar</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Pradipta Das</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sanchari Dhar</h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Suman Maity</h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Suman Maity</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sudhanya Sinha</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Anirban Adhikari</h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Nilrohit Dey
                            </h5>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="container-fluid py-6 green_bg">
        <div class="container">

            <div class="heading text-center">
                <p>The Fraternity Stalwarts</p>
                <h2>Organizing Committee</h2>
                <span>Committee</span>
            </div>
            <div class="row">
                <h4 class="col-12 mb-4 ">Cardiology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sunip Banerjee</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Prakash Chandra Mondai</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Arindam Pande</h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sabyasachi Paul</h5>

                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Critical Care</h4>

                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Arindam Kar
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sauren Panja
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Amrita Bhattacharyya

                            </h5>

                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Dermatology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Koushik Lahiri
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sudip Das
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Somenath Sarkar
                            </h5>

                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Digital Health</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Prantar Chakrabarti
                            </h5>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Subhrojyoti Bhowmick
                            </h5>

                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Endocrinology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Nilanjan Sengupta</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Debmalya Sanyal</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Soumik Goswami</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Forensic Medicine & Toxicology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Biswajit Sukul</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Saurabh Chattopadhyay</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sayak Sovan Dutta</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Gastroenterology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Asokananda Konar</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sujit Chaudhuri</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sandip Pal</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Geriatric Medicine</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Krishnendu Roy</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Himadri Das</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Suman Mitra</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Hematology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Utpal Chowdhury</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Tuphan Kanti Dolui</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Basab Bagchi</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Internal Medicine</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Soumitra Ghosh</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Partha Sarathi Karmakar</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Saikat Dutta</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Medical Pharmacology & Therapeutics</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Santanu Munshi

                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sukanta Sen
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Ananya Mandal</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Medical Education</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Avijit Hazra</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sharmistha Biswas
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Partha Pratim Prodhan</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Medical Oncology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Swarnabindu Banerjee</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Poulami Basu
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Tanmoy Mandal</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Nephrology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Pratik Das
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Manish Jain
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Smartya Pulai</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Neurology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Jayanta Roy
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Subhadeep Banerjee
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Soumava Mukherjee</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Pathology & Lab Medicine</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Tamal Kanti Ghosh </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Pradip Kumar Dhar
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sayed Mahmood Nadeem</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Physical Medicine & Rehabilitation</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sankar Prasad Sinha</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Rathindranath Haldar
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Dilip Khatua</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Swapan Kumar Mishra</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Psychiatry</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Ranadip Ranjan Ghosh Roy</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Ranjan Bhattacharyya
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Sabyasachi Mitra</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Respiratory Medicine</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Aloke Gopal Ghoshal</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Arup Haldar
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Subhasis Mukherjee</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Rheumatology</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Parashar Ghosh</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Kaushik Basu
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Parthajit Das</h5>
                        </div>
                    </div>
                </div>
                <h4 class="col-12 mb-4 mt-5">Tropical Medicine</h4>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Bibhuti Saha</h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Amartya Kumar Misra
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 my-3">
                    <div class="committeeboc">
                        <div class="comimg">
                            <img src="https://www.pngkey.com/png/detail/839-8393808_user-male-silhouette-comments-blank-person.png" alt="">
                        </div>
                        <div class="desg">
                            <h5>Dr Soumendranath Halda</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once("includes/footer.php"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
</body>
<script>
    $(document).ready(function() {
        $('.faq-clk').click(function() {
            if ($(this).hasClass("active")) {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(".faq-clk").parent().removeClass("active");
            } else {
                $(".faqx").slideUp();
                $(".faq-clk").removeClass("active");
                $(".faq-clk").parent().removeClass("active");
                $(this).parent().find(".faqx").slideToggle();
                $(this).parent().toggleClass("active");
                $(this).parent().find(".faq-clk").toggleClass("active");
            }
        });
    });

    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<script>
    $(document).ready(function() {
        setTimeout(function() {
            $('.loader').fadeOut(500);
        }, 5000);
    });
    /*---------dynamic tab--------*/
    $(document).ready(function() {
        $(document).on("click", ".tabsitem", function() {
            $('.tabsitem').removeClass('active');
            $(this).addClass('active');
            var currentTab = $(this).attr('data-id');
            $('.schedule-content').removeClass('active');
            $('#' + currentTab).addClass('active');
        });
    });

    new WOW().init();

    $('.bannerslide').owlCarousel({
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: false,
        center: true,
        items: 1,
        loop: true,
        nav: false,
        dots: false,
        margin: 0,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        responsive: {
            600: {
                items: 1
            }
        }
    });

    $('.cityslide').owlCarousel({
        center: true,
        items: 1,
        loop: true,
        nav: true,
        margin: 10,
        responsive: {
            600: {
                items: 1
            }
        }
    });
    $('.conseptslide').owlCarousel({
        items: 4,
        loop: false,
        nav: true,
        dots: false,
        margin: 10,
        responsive: {
            600: {
                items: 1
            },
            1024: {
                items: 4
            }
        }
    });

    $('.userslide').owlCarousel({
        center: true,
        items: 1,
        loop: true,
        nav: false,
        margin: 0,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        autoplay: true,
        responsive: {
            600: {
                items: 1
            }
        }
    });
</script>
<script>
    $(function() {
        $('.popup-youtube, .popup-vimeo').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: false,
            fixedContentPos: false
        });
    });
</script>
<script>
    var randomScalingFactor = function() {
        return Math.round(Math.random() * 100);
    };

    var randomData = function() {
        return [
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor()
        ];
    };

    var randomValue = function(data) {
        return Math.max.apply(null, data) * Math.random();
    };

    var data = randomData();
    var value = randomValue(data);

    var config = {
        type: 'gauge',
        data: {
            labels: ['Success', 'Warning', 'Warning', 'Error'],
            datasets: [{
                data: data,
                value: value,
                backgroundColor: ['#0b152c', '#3e3f3e', '#dc1e33', '#c32032'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,

            },
            layout: {
                padding: {
                    bottom: 30
                }
            },
            needle: {
                // Needle circle radius as the percentage of the chart area width
                radiusPercentage: 2,
                // Needle width as the percentage of the chart area width
                widthPercentage: 3.2,
                // Needle length as the percentage of the interval between inner radius (0%) and outer radius (100%) of the arc
                lengthPercentage: 80,
                // The color of the needle
                color: 'rgba(14, 30, 42, 1)'
            },
            valueLabel: {
                formatter: Math.round
            }
        }
    };

    window.onload = function() {
        var ctx = document.getElementById('chart').getContext('2d');
        window.myGauge = new Chart(ctx, config);
    };

    document.getElementById('randomizeData').addEventListener('click', function() {
        config.data.datasets.forEach(function(dataset) {
            dataset.data = randomData();
            dataset.value = randomValue(dataset.data);
        });

        window.myGauge.update();
    });
</script>
<script>
    const counters = document.querySelectorAll(".counter");

    counters.forEach((counter) => {
        counter.innerText = "0";
        const updateCounter = () => {
            const target = +counter.getAttribute("data-target");
            const count = +counter.innerText;
            const increment = target / 200;
            if (count < target) {
                counter.innerText = `${Math.ceil(count + increment)}`;
                setTimeout(updateCounter, 1);
            } else counter.innerText = target;
        };
        updateCounter();
    });
    class AtroposComponent extends HTMLElement {
        constructor() {
            super();
        }

        connectedCallback() {
            this.atropos = new Atropos({
                el: this.querySelector('.atropos'),
                onEnter() {
                    console.log('Atropos Component: Enter');
                },
                onLeave() {
                    console.log('Atropos Component: Leave');
                },
                onRotate(x, y) {
                    console.log('Atropos Component: Rotate', x, y);
                }
            });

            console.log('Atropos Component: Connected!', this);
        }

        disconnectedCallback() {
            this.atropos.destroy();

            console.log('Atropos Component: Disconnected!', this);
        }
    }

    customElements.define('atropos-component', AtroposComponent);
    particlesJS("particles-js", {
        "particles": {
            "number": {
                "value": 6,
                "density": {
                    "enable": true,
                    "value_area": 800
                }
            },
            "color": {
                "value": "#d5d52b"
            },
            "shape": {
                "type": "circle",
                "stroke": {
                    "width": 0,
                    "color": "#000000"
                },
                "polygon": {
                    "nb_sides": 0
                },
                "image": {
                    "src": "img/github.svg",
                    "width": 100,
                    "height": 100
                }
            },
            "opacity": {
                "value": 0.5,
                "random": false,
                "anim": {
                    "enable": false,
                    "speed": 1,
                    "opacity_min": 0.1,
                    "sync": false
                }
            },
            "size": {
                "value": 8,
                "random": true,
                "anim": {
                    "enable": false,
                    "speed": 3,
                    "size_min": 1,
                    "sync": false
                }
            },
            "line_linked": {
                "enable": false,
                "distance": 150,
                "color": "#ffffff",
                "opacity": 0.4,
                "width": 1
            },
            "move": {
                "enable": true,
                "speed": 3,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "bounce": false,
                "attract": {
                    "enable": false,
                    "rotateX": 600,
                    "rotateY": 1200
                }
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
                "onhover": {
                    "enable": true,
                    "mode": "grab"
                },
                "onclick": {
                    "enable": true,
                    "mode": "push"
                },
                "resize": true
            },
            "modes": {
                "grab": {
                    "distance": 140,
                    "line_linked": {
                        "opacity": 1
                    }
                },
                "bubble": {
                    "distance": 400,
                    "size": 40,
                    "duration": 2,
                    "opacity": 8,
                    "speed": 3
                },
                "repulse": {
                    "distance": 200,
                    "duration": 0.4
                },
                "push": {
                    "particles_nb": 4
                },
                "remove": {
                    "particles_nb": 2
                }
            }
        },
        "retina_detect": true
    });


    /* ---- stats.js config ---- */

    var count_particles, stats, update;
    stats = new Stats;
    stats.setMode(0);
    stats.domElement.style.position = 'absolute';
    stats.domElement.style.left = '0px';
    stats.domElement.style.top = '0px';
    document.body.appendChild(stats.domElement);
    count_particles = document.querySelector('.js-count-particles');
    update = function() {
        stats.begin();
        stats.end();
        if (window.pJSDom[0].pJS.particles && window.pJSDom[0].pJS.particles.array) {
            count_particles.innerText = window.pJSDom[0].pJS.particles.array.length;
        }
        requestAnimationFrame(update);
    };
    requestAnimationFrame(update);
</script>


</html>