<header class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12 d-flex align-items-center topbar-one__inner">
                <div class="topbar-one__logo">
                    <a href="index.php">
                        <img src="images/logo.png" alt="Logo" width="161">
                    </a>
                </div>
                <a class="topbar-one__volunter" href="tel:+92(8800)-6930"><span class="icn"><i class="fas fa-heart"></i></span><span>Become a volunteers</span></a>
                <div class="topbar-one__right">
                    <a class="topbar-one__info" href="tel:9288609630">
                    <i class="fas fa-phone topbar-one__info__icon" style="transform: rotate(90deg)"></i>
                        <span class="topbar-one__info__content">
                            <span class="topbar-one__info__text">Call anytime</span>
                            <span class="topbar-one__info__number">+92 (8860) - 9630</span>
                        </span>
                    </a><!-- /.topbar-one__text -->
                    <a class="topbar-one__info" href="mailto:needhelp@company.com">
                    <i class="fas fa-envelope topbar-one__info__icon"></i>
                        <span class="topbar-one__info__content">
                            <span class="topbar-one__info__text">Send Mail</span>
                            <span class="topbar-one__info__number">needhelp@company.com</span>
                        </span>
                    </a><!-- /.topbar-one__text -->
                    <div class="topbar-one__social ">
                        <a href="https://twitter.com">
                            <i class="fab fa-twitter" aria-hidden="true"></i>
                            <span class="sr-only">Twitter</span>
                        </a>
                        <a href="https://facebook.com">
                            <i class="fab fa-facebook" aria-hidden="true"></i>
                            <span class="sr-only">Facebook</span>
                        </a>
                        <a href="https://pinterest.com">
                            <i class="fab fa-pinterest-p" aria-hidden="true"></i>
                            <span class="sr-only">Pinterest</span>
                        </a>
                        <a href="https://instagram.com">
                            <i class="fab fa-instagram" aria-hidden="true"></i>
                            <span class="sr-only">Instagram</span>
                        </a>
                    </div><!-- /.topbar-one__social -->
                </div>

            </div>

            <div class="menu-box col-md-12 d-flex align-items-center" id="collapsemenu">
                <div class="menu-box-rt">
                    <button class="mobile-nav__btn" onclick="$('.navigation').addClass('menu-open');" ><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('menu-open');" style="position: absolute;right: 19px;border: 0;background: transparent; color: white; top: 14px;font-size: 16px;"><i class="fas fa-times"></i></button>
                        <ul class="nav-menu">
                            <li><a>Home</a></li>
                            <li><a>About us </a></li>
                            <li><a>Master Class</a></li>
                            <li><a>Programme</a></li>
                            <li><a>Committees </a></li>
                            <li><a>Registration</a></li>
                            <li><a>Download </a></li>
                            <li><a>Accommodation</a></li>
                            <li><a>Tourism </a></li>
                            <li><a>Contact Us</a></li>
                        </ul>
                        <ul class="mobile-nav__contact list-unstyled d-md-none">
                            <li>
                                <i class="fa fa-envelope"></i>
                                <a href="mailto:needhelp@aofixo.com">needhelp@aofixo.com</a>
                            </li>
                            <li>
                                <i class="fas fa-phone" style="transform: rotate(90deg)"></i>
                                <a href="tel:666-888-0000">666 888 0000</a>
                            </li>
                        </ul>
                        <div class="mobile-nav__social d-md-none">
                            <a href="https://twitter.com">
                                <i class="fab fa-twitter" aria-hidden="true"></i>
                                <span class="sr-only">Twitter</span>
                            </a>
                            <a href="https://facebook.com">
                                <i class="fab fa-facebook" aria-hidden="true"></i>
                                <span class="sr-only">Facebook</span>
                            </a>
                            <a href="https://pinterest.com">
                                <i class="fab fa-pinterest-p" aria-hidden="true"></i>
                                <span class="sr-only">Pinterest</span>
                            </a>
                            <a href="https://instagram.com">
                                <i class="fab fa-instagram" aria-hidden="true"></i>
                                <span class="sr-only">Instagram</span>
                            </a>
                        </div>
                    </nav>
                    <a href="#" class="download"><i class="fas fa-download"></i></a>
                </div>
                <a href="#" class="regi-login"><i class="fas fa-user"></i><span class="d-none d-md-block">Register/Login</span></a>
            </div>
        </div>
    </div>
</header>