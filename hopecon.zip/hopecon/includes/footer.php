<footer class="bg-gradient-aztec-green position-relative">
  <div class="position-absolute left-minus-100px top-25px">
    <img src="images/demo-elearning-bg-05.png" alt class="w-80">
  </div>
  <div class="background-position-center-top w-100 position-absolute left-0px top-0" style="background-image: url('images/vertical-line-bg-small.svg')"></div>

  <div class="container footer-dark text-center text-sm-left position-relative">
    <div class="row sm-mb-7 xs-mb-30px">
      <div class="col-lg-3 col-md-12 col-sm-6 text-md-center text-lg-left">
          <a href="demo-elearning.html" class="footer-logo mb-15px d-inline-block">
          <img src="images/logo2.png" data-at2x="images/logo2.png" alt>
        </a>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 d-flex flex-column last-paragraph-no-margin md-mb-40px xs-mb-30px mb-5">
       
        <p class="lh-28">We are providing high-quality courses for about ten years.</p>
        <div class="elements-social social-text-style-01 mt-9 xs-mt-15px">
          <ul class="small-icon light fw-500">
            <li>
              <a class="facebook" href="https://www.facebook.com/" target="_blank">Fb.</a>
            </li>
            <li>
              <a class="instagram" href="https://www.instagram.com" target="_blank">Ig.</a>
            </li>
            <li>
              <a class="twitter" href="https://www.twitter.com" target="_blank">Tw.</a>
            </li>
            <li>
              <a class="behance" href="http://www.behance.com/" target="_blank">Be.</a>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 ps-4 last-paragraph-no-margin md-mb-40px xs-mb-30px mb-5">
        <span class="fw-500 fs-18 d-block text-white mb-10px">Popular courses</span>
        <ul>
          <li>
            <a href="demo-elearning-courses.html">Business finance</a>
          </li>
          <li>
            <a href="demo-elearning-courses.html">Advanced design</a>
          </li>
          <li>
            <a href="demo-elearning-courses.html">Web development</a>
          </li>
          <li>
            <a href="demo-elearning-courses.html">Data visualization</a>
          </li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 last-paragraph-no-margin xs-mb-30px mb-5">
        <span class="fw-500 fs-18 d-block text-white mb-10px">Need help?</span>
        <span class="lh-26 d-block">Call us directly?</span>
        <span class="text-white d-block mb-10px">
          <a href="tel:12345678910">+1 234 567 8910 </a>
          <span class="bg-base-color fw-700 text-dark-gray lh-22 text-uppercase border-radius-30px ps-10px pe-10px fs-11 ms-5px d-inline-block align-middle">Free</span>
        </span>
        <span class="lh-26 d-block">Need support?</span>
        <a href="/cdn-cgi/l/email-protection#3f575a534f7f5b50525e5651115c5052" class="text-white text-decoration-line-bottom">
          demoemail@email.com
        </a>
      </div>
    </div>
    <div class="row align-items-center footer-bottom border-top border-color-transparent-white-light pt-30px g-0">
      <div class="col-xl-7 ps-0 text-center text-xl-left lg-mb-10px">
        <ul class="footer-navbar fs-16 lh-normal">
          <li class="nav-item active">
            <a href="demo-elearning.html" class="nav-link ps-0">Home</a>
          </li>
          <li class="nav-item">
            <a href="demo-elearning-about.html" class="nav-link">About</a>
          </li>
          <li class="nav-item">
            <a href="demo-elearning-courses.html" class="nav-link">Courses</a>
          </li>
          <li class="nav-item">
            <a href="demo-elearning-instructors.html" class="nav-link">Instructors</a>
          </li>
          <li class="nav-item">
            <a href="demo-elearning-testimonial.html" class="nav-link">Testimonial</a>
          </li>
          <li class="nav-item">
            <a href="demo-elearning-blog.html" class="nav-link">Blog</a>
          </li>
          <li class="nav-item">
            <a href="demo-elearning-contact.html" class="nav-link">Contact</a>
          </li>
        </ul>
      </div>
      <div class="col-xl-5 last-paragraph-no-margin text-center text-xl-end">
        <p class="fs-16">&copy; 2024 | <a href="#" target="_blank" class="text-white text-decoration-line-bottom">Company name</a> | <img src="images/logo2.png" style="max-width:120px" alt>
        </p>
      </div>
    </div>
  </div>
</footer>